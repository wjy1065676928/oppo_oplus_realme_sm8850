#!/system/bin/sh

wait_key() {
  getevent -qt 1 >/dev/null 2>&1
  while true; do
    local event=$(getevent -lqc 1 2>/dev/null)
    case "$event" in
      *KEY_VOLUMEDOWN*DOWN*)  echo "down" && return ;;
      *KEY_VOLUMEUP*DOWN*)    echo "up"   && return ;;
    esac
    usleep 50000
  done
}

show_menu() {
  local choice=$1
  echo ""
  echo "  ╔══════════════════════════════════════╗"
  echo "  ║     ZRAM 模块 — zsmalloc 选择       ║"
  echo "  ╠══════════════════════════════════════╣"
  if [ "$choice" = "0" ]; then
    echo "  ║  ➤ 使用 GKI 编译的 zsmalloc.ko     ║"
    echo "  ║     使用设备自带的 zsmalloc         ║"
  else
    echo "  ║     使用 GKI 编译的 zsmalloc.ko     ║"
    echo "  ║  ➤ 使用设备自带的 zsmalloc         ║"
  fi
  echo "  ╠══════════════════════════════════════╣"
  echo "  ║  🔼 音量上 = 切换   🔽 音量下 = 确认 ║"
  echo "  ║  ⏱  30 秒无操作 = 默认 GKI         ║"
  echo "  ╚══════════════════════════════════════╝"
  echo ""
}

echo ""
echo "⚠️  如果设备内核已自带 zsmalloc.ko，使用模块的zram.ko"
echo "   可能无法加载。"
echo ""
echo "   如果开机后发现 zram 不工作，重新刷入"
echo "   模块并选择 GKI 的 zsmalloc.ko 即可。"
echo ""

if ! command -v getevent >/dev/null 2>&1; then
  echo "⚠️  getevent 不可用，默认使用 GKI 版本"
  echo "********************************************"
  exit 0
fi

choice=0
while true; do
  show_menu "$choice"
  key=$(wait_key)
  case "$key" in
    up)   choice=$((1 - choice)) ;;
    down) break ;;
  esac
done

echo ""
echo "********************************************"
if [ "$choice" = "0" ]; then
  echo "✅ 使用 GKI 编译的 zsmalloc.ko"
else
  echo "✅ 使用设备自带的 zsmalloc"
  echo "   移除 GKI zsmalloc.ko..."
  rm -f "$TMPDIR/zsmalloc.ko"
fi
echo "********************************************"
echo ""
